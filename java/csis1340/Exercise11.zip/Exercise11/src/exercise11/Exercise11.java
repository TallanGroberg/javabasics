
package exercise11;
import java.util.Scanner;
/**
 *
 * @author Tallan Groberg
 */
public class Exercise11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("a number greater than 0");

        int N = input.nextInt();
        int counter = 0;
        System.out.println("your number is: " + N);
        while((N + 1) > counter) {
            System.out.println(counter);
            counter++;
        }
    }
}
