/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package powersof2;

/**
 *
 * @author tallan
 */
public class PowersOf2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int count = 10;
        for (int i = 0; i < (count + 1); i++) 
        {
            int x = i;  
            double powerOftwo = Math.pow(2, x);

            System.out.println("2 to the power of " + x + " power is: " + powerOftwo);
        }
    }
    
}
